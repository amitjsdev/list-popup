import React,{useState} from 'react';
import ContentList from './components/ContentList';
import './styles.css';
function App() {
  return (
    <div className="App">
      <ContentList/>
    </div>
  );
}

export default App;
