import React, { useState, useRef, useEffect } from "react";
import {
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  Input
} from "reactstrap";
import "bootstrap/dist/css/bootstrap.min.css";

export default function ModalPopup(props) {
 const {toggle,modalData,modal} = props;

  return (
    <div className="App">
      <div>
        <Modal isOpen={modal} toggle={toggle} className={`modals`}>
          <ModalHeader toggle={toggle}> {modalData?.name} </ModalHeader>
          <ModalBody>
              {modalData?.descp} 
          </ModalBody>
          <ModalFooter>
            <Button color="secondary" onClick={toggle}>Cancel</Button>
          </ModalFooter>
        </Modal>  </div>
    </div>
  );
}
