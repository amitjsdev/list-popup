import React,{useState} from 'react';

import './styles.css';
import ContentList from './components/ContentList';
import Second from './components/Modal';
function App() {
  return (
    <div className="App">
      <ContentList/>
    </div>
  );
}

export default App;
